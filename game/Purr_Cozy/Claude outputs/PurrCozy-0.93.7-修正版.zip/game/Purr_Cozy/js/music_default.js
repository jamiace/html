/* ============================================================
   Built-in YouTube playlist (小窩電台)
   - Only new players with no previous selection start from the radio.
     Existing local/library/YouTube selections and positions are retained.
   - its songs are listed in the music window (內建音樂 → 小窩電台); tap one to play it
   - the first tap resumes the previous source; only a new radio session starts randomly
     (browsers never let a page play sound before the first tap); pausing it yourself turns
     this off until you press play again
   ============================================================ */
const NOOK_YT = { id: 'yt_nook', type: 'yt', list: 'PL_77ETNrRb7Ep0Zv3tQNLNxQgwTsTHNrV', title: I18n.s("u_b98b2b8dc092"), builtin: true };

const MusicDefault = {
  armed: false, shuffleNext: false, target: null, curVid: '',
  setup() {
    const M = Game.S.music; if (!M) return;
    const oldIndex = M.idx;
    const selected = M.list[oldIndex];
    const fresh = M.ctx !== 'lib' && !selected && !M.last;
    if (!M.list.some(e => e.type === 'yt' && e.list === NOOK_YT.list)) {
      M.list.unshift(Object.assign({}, NOOK_YT));
      if (oldIndex >= 0) M.idx = oldIndex + 1;
    }
    const radio = M.list.find(e => e.type === 'yt' && e.list === NOOK_YT.list);
    radio.id = NOOK_YT.id;
    M.ytDefaultV = 1; M.ytAdded = true;
    if (fresh) { M.ctx = 'list'; M.idx = M.list.indexOf(radio); M.autoOff = false; }
    if (M.ctx === 'list') Music.cur = M.list[M.idx] || null;
    if (UI.mTab == null) UI.mTab = M.ctx === 'lib' || (Music.cur && Music.cur.id === NOOK_YT.id) ? 'lib' : 'list';
    this.armed = M.autoOff !== true;
    if (this.armed && Music.cur && Music.cur.type === 'yt' && window.NOOK_ENV === 'web') Music.loadYTApi().catch(() => { });
  },
  // ---------- the playlist's songs ----------
  tracks() {
    const known = new Map(NOOK_YT_TRACKS.map(r => [r[0], r]));
    let ids = []; try { if (this.isOn() && Music.yt && Music.ytReady && Music.yt.getPlaylist) ids = Music.yt.getPlaylist() || []; } catch (e) { }
    // the player's own list (shuffled order) is used only to add songs that are not listed here yet
    const out = NOOK_YT_TRACKS.map(r => ({ id: r[0], t: r[1], by: r[2], len: r[3] }));
    for (const id of ids) if (!known.has(id)) out.push({ id, t: '', by: '', len: '' });
    return out;
  },
  isOn() { return !!(Music.cur && Music.cur.id === NOOK_YT.id); },
  // play one song of the playlist
  play(vid) {
    const M = Game.S.music, i = M.list.findIndex(e => e.id === NOOK_YT.id);
    if (M.last && M.last.id === NOOK_YT.id) { M.last.vid = vid; M.last.position = 0; } Music._resume = 0;
    if (i < 0) { M.list.unshift(Object.assign({}, NOOK_YT)); if (M.idx >= 0) M.idx++; }
    if (this.isOn() && Music.yt && Music.ytReady) {
      try { const pl = Music.yt.getPlaylist() || [], k = pl.indexOf(vid); if (k >= 0) { Music.yt.playVideoAt(k); return; } } catch (e) { }
    }
    this.target = vid; this.shuffleNext = false; Music.playIdx(M.list.findIndex(e => e.id === NOOK_YT.id));
  },
  // The first gesture resumes the last source; a new radio listener starts randomly.
  first() {
    if (!this.armed) return; this.armed = false;
    if (Music.playing) return;
    if (Game.S.music.autoOff === true) return;
    const last = Game.S.music.last;
    this.shuffleNext = this.isOn() && !(last && last.vid);
    Music.toggle(true);
  },
};

(function () {
  const init = Music.init.bind(Music);
  Music.init = function () { const r = init(); try { MusicDefault.setup(); } catch (e) { console.warn('[music]', e); } return r; };
  // a pause you chose yourself turns the automatic start off; pressing play turns it back on
  const tog = Music.toggle.bind(Music);
  Music.toggle = function (force) {
    if (force === undefined && Game.S && Game.S.music) { const M = Game.S.music, off = !!Music.playing; if (M.autoOff !== off) { M.autoOff = off; Game.save(); } MusicDefault.armed = false; }
    return tog(force);
  };
  const pa = Music.playAt.bind(Music);
  Music.playAt = function (i) { MusicDefault.armed = false; if (Game.S && Game.S.music && Game.S.music.autoOff) { Game.S.music.autoOff = false; } return pa(i); };
  // the built-in playlist starts on a random track and keeps shuffling
  const st = Music.onYTState.bind(Music);
  Music.onYTState = function (ev) {
    const e = this.cur;
    // which song is on: highlighted in the list
    if (e && e.id === NOOK_YT.id && ev.data === 1) { try { const v = (this.yt.getVideoData() || {}).video_id || ''; if (v !== MusicDefault.curVid) { MusicDefault.curVid = v; UI.refresh('music'); const r = NOOK_YT_TRACKS.find(x => x[0] === v), tt = document.querySelector('#ytpanel .yt-title'), nm = r ? r[1] : ((this.yt.getVideoData() || {}).title || ''); if (tt && nm) tt.textContent = I18n.t("u_06eceed05d03") + nm;   /* .yt-title is not auto-translated (song names), so the label is translated here */ } } catch (x) { } }
    if (e && e.id === NOOK_YT.id && this.yt && (ev.data === 1 || ev.data === 5 || ev.data === -1)) {
      try {
        const pl = this.yt.getPlaylist() || [];
        if (pl.length) {
          this.yt.setShuffle(true); this.yt.setLoop(true);
          if (MusicDefault.target) { const k = pl.indexOf(MusicDefault.target); MusicDefault.target = null; if (k >= 0 && k !== this.yt.getPlaylistIndex()) { this.yt.playVideoAt(k); return; } }
          if (MusicDefault.shuffleNext) { MusicDefault.shuffleNext = false; const k = Math.floor(Math.random() * pl.length); if (k !== this.yt.getPlaylistIndex()) { this.yt.playVideoAt(k); return; } }
        }
      } catch (x) { }
    }
    return st(ev);
  };
  // (a first tap on a play button is left to that button)
  for (const ev of ['pointerdown', 'keydown']) document.addEventListener(ev, e => { try { if (e.target && e.target.closest && e.target.closest(I18n.s("u_e3817258409a"))) { MusicDefault.armed = false; return; } MusicDefault.first(); } catch (x) { } }, true);
})();

// computer: the YouTube player goes in the free space beside the room, never over the furniture
// (dragged by its title bar, it stays where you put it; a narrow window keeps the old corner)
const YTPlace = {
  apply() {
    const yp = document.getElementById('ytpanel'), wrap = document.querySelector('.room-wrap');
    if (YTMiniPlace.apply()) return;
    if (!yp || yp.hidden || !wrap || document.body.classList.contains('m') || yp.dataset.moved) return;
    const r = wrap.getBoundingClientRect(), gl = r.left, gr = window.innerWidth - r.right, gap = Math.max(gl, gr) - 12;
    // YouTube needs at least 200 × 200 px for its player: a slim frame fits from 204 px of free space
    if (gap < 204) { yp.classList.remove('yt-side'); yp.style.width = ''; yp.style.left = ''; yp.style.right = ''; yp.style.top = ''; yp.style.bottom = ''; return; }
    yp.classList.add('yt-side');
    const w = Math.min(372, gap), hgt = yp.offsetHeight || 230, top = Math.max(8, Math.min(window.innerHeight - hgt - 8, r.bottom - hgt));
    yp.style.width = w + 'px'; yp.style.top = top + 'px'; yp.style.bottom = 'auto';
    // the left side first (the hand tray uses the right side)
    if (gl - 12 >= 204 || gl >= gr) { yp.style.left = Math.max(8, (gl - w) / 2) + 'px'; yp.style.right = 'auto'; }
    else { yp.style.left = Math.round(r.right + (gr - w) / 2) + 'px'; yp.style.right = 'auto'; }
  },
};
(function () {
  const show = UI.ytPanel.bind(UI);
  UI.ytPanel = function (on) { const r = show.apply(this, arguments); requestAnimationFrame(() => YTPlace.apply()); return r; };
  window.addEventListener('resize', () => YTPlace.apply());
  window.addEventListener('load', () => { const yh = document.querySelector('#ytpanel .yt-h'); if (yh) yh.addEventListener('pointerdown', e => { if (!e.target.closest('button') && !document.body.classList.contains('m')) document.getElementById('ytpanel').dataset.moved = '1'; }); });
})();

// music window: 小窩電台 is the first album of 內建音樂, with every song of the playlist
(function () {
  const RADIO = '__yt';
  const lib = UI.musicLib.bind(UI);
  const card = (on) => h('button', { class: 'malbum radio' + (on ? ' on' : ''), title: I18n.s("u_b98b2b8dc092"), onclick: () => { UI.mAlbum = RADIO; UI.refresh('music'); } },
    h('div', { class: 'mal-ph radio' }, ico('i_video', 36)), h('b', { text: I18n.s("u_5aa44450caac") }), h('span', { class: 'hint', text: I18n.s("u_f97af1b28608", [MusicDefault.tracks().length]) }));
  const tab = (on) => h('button', { class: 'tab sm' + (on ? ' on' : ''), onclick: () => { UI.mAlbum = RADIO; UI.refresh('music'); } }, I18n.s("u_304a979aff76", [MusicDefault.tracks().length]));
  UI.musicLib = function () {
    // the radio is what plays and nothing else was picked here yet: open on its songs
    if (this.mAlbum == null && MusicDefault.isOn()) this.mAlbum = RADIO;
    const radio = this.mAlbum === RADIO, keep = this.mAlbum;
    if (radio) this.mAlbum = '';            // let the library draw its album row as for "全部"
    let out; try { out = lib(); } finally { this.mAlbum = keep; }
    const wrap = h('div', {}, ...out);
    const cards = wrap.querySelector('.malbums'), tabs = wrap.querySelector('.mlib-al');
    if (cards) { if (radio) cards.querySelectorAll('.malbum.on').forEach(b => b.classList.remove('on')); cards.prepend(card(radio)); }
    else if (tabs) { if (radio) tabs.querySelectorAll('.tab.on').forEach(b => b.classList.remove('on')); tabs.prepend(tab(radio)); }
    let items = [...wrap.children];
    if (!cards && !tabs) items.unshift(h('div', { class: 'row' }, h('div', { class: 'tabs wrap mlib-al' }, tab(radio))));
    if (!radio) return items;
    // the radio's own songs instead of the library's play row and track list
    const T = MusicDefault.tracks(), on = MusicDefault.isOn(), cur = on ? MusicDefault.curVid : '';
    const head = h('div', { class: 'row' }, h('button', { class: 'chip primary sm', onclick: () => MusicDefault.play(T[Math.floor(Math.random() * T.length)].id) }, ico('i_shuffle', 16), I18n.s("u_184289218952")),
      h('span', { class: 'hint grow', text: I18n.s("u_0f34a601535d") }));
    const list = h('div', { class: 'scroll mtracks' }, h('ol', { class: 'mlist' }, ...T.map((r, i) => h('li', { class: r.id === cur ? 'cur' : '' },
      h('button', { class: 'mplay', title: r.t ? `${r.t}${r.by ? ' · ' + r.by : ''}` : I18n.s("u_53bd1b6739f4", [i + 1]), onclick: () => MusicDefault.play(r.id) },
        h('span', { class: 'mi num', text: String(i + 1) }), h('span', { class: 'mn', text: r.t || I18n.s("u_53bd1b6739f4", [i + 1]) }), r.len ? h('em', { class: 'mb num', text: r.len }) : null)))));
    const playRow = items.findIndex(el => el.matches && el.matches('.row') && el.querySelector('.chip.primary'));
    const trk = items.findIndex(el => el.matches && el.matches('.mtracks'));
    items = items.filter((el, k) => k !== playRow && k !== trk && !(el.matches && el.matches('.mcache, .empty, .hint.center')));
    items.push(head, list);
    return items;
  };
})();

// Keep the live iframe in place: moving it in the DOM can reload playback.
// Only CSS coordinates change when the compact bar is dragged or docked.
const YTMiniPlace = {
  key: 'pocketnook.ytposition', positions: null,
  state() {
    if (!this.positions) { try { this.positions = JSON.parse(localStorage.getItem(this.key)) || {}; } catch (e) { this.positions = {}; } }
    const key = document.body.classList.contains('m') ? 'mobile' : 'desktop';
    return this.positions[key] || (this.positions[key] = { mode: 'dock' });
  },
  save() { try { localStorage.setItem(this.key, JSON.stringify(this.positions)); } catch (e) { } },
  reserve(px) { const root = document.documentElement, value = px + 'px'; if (root.style.getPropertyValue('--yt-mini-height') !== value) root.style.setProperty('--yt-mini-height', value); },
  dock() { const s = this.state(); s.mode = 'dock'; this.save(); YTMini.set(true); this.apply(); },
  bounds(yp) {
    const m = document.body.classList.contains('m'), css = getComputedStyle(document.documentElement);
    const kb = m ? parseFloat(css.getPropertyValue('--kb')) || 0 : 0;
    const nav = m ? document.querySelector('.mnav') : document.querySelector('.dock');
    const bottom = nav && nav.getClientRects().length ? Math.max(0, window.innerHeight - nav.getBoundingClientRect().top) : kb;
    return { m, bottom: Math.max(kb, bottom), w: Math.min(372, window.innerWidth - 16), h: yp.offsetHeight };
  },
  apply() {
    const yp = document.getElementById('ytpanel');
    if (!yp || yp.hidden || !yp.classList.contains('min')) {
      this.reserve(0);
      if (yp && yp.classList.contains('yt-compact')) { yp.classList.remove('yt-compact'); for (const k of ['left', 'right', 'top', 'bottom', 'width']) yp.style[k] = ''; delete yp.dataset.moved; }
      return false;
    }
    yp.classList.remove('yt-side'); yp.classList.add('yt-compact');
    const s = this.state(); yp.style.width = Math.min(372, window.innerWidth - 16) + 'px';
    const b = this.bounds(yp); yp.style.right = 'auto';
    if (s.mode === 'float') {
      this.reserve(0);
      s.x = Math.max(8, Math.min(window.innerWidth - b.w - 8, Number.isFinite(s.x) ? s.x : 8));
      s.y = Math.max(8, Math.min(window.innerHeight - b.bottom - b.h - 8, Number.isFinite(s.y) ? s.y : 8));
      yp.style.left = s.x + 'px'; yp.style.top = s.y + 'px'; yp.style.bottom = 'auto';
    } else {
      yp.style.left = Math.max(8, (window.innerWidth - b.w) / 2) + 'px'; yp.style.top = 'auto';
      yp.style.bottom = b.m ? 'calc(var(--kb, 0px) + var(--mobile-nav-height, 60px) + 8px)' : (b.bottom + 8) + 'px';
      this.reserve(b.m ? b.h + 16 : 0);
    }
    return true;
  },
  build() {
    const yp = document.getElementById('ytpanel'), hd = yp && yp.querySelector('.yt-h'); if (!hd) return;
    hd.querySelector('.yt-title').title = I18n.s("u_70ead01caba8");
    hd.addEventListener('pointerdown', e => {
      if (!yp.classList.contains('min') || e.target.closest('button') || (e.pointerType === 'mouse' && e.button !== 0)) return;
      e.preventDefault(); e.stopImmediatePropagation();
      const r = yp.getBoundingClientRect(), ox = e.clientX - r.left, oy = e.clientY - r.top, s = this.state();
      s.mode = 'float'; s.x = r.left; s.y = r.top; this.apply(); hd.setPointerCapture(e.pointerId);
      const move = ev => { if (ev.pointerId !== e.pointerId) return; s.x = ev.clientX - ox; s.y = ev.clientY - oy; this.apply(); };
      const end = ev => { if (ev.pointerId !== e.pointerId) return; hd.removeEventListener('pointermove', move); for (const n of ['pointerup', 'pointercancel', 'lostpointercapture']) hd.removeEventListener(n, end); this.save(); };
      hd.addEventListener('pointermove', move); for (const n of ['pointerup', 'pointercancel', 'lostpointercapture']) hd.addEventListener(n, end);
    }, true);
  },
};

// the YouTube player can shrink to its title bar and keep playing (a phone has no room for the video);
// remembered on this device, a phone starts shrunk
const YTMini = {
  key: 'pocketnook.ytmin',
  get() { try { const v = localStorage.getItem(this.key); if (v != null) return v === '1'; } catch (e) { } return document.body.classList.contains('m'); },
  set(v) { try { localStorage.setItem(this.key, v ? '1' : '0'); } catch (e) { } this.apply(); },
  apply() {
    const yp = document.getElementById('ytpanel'); if (!yp) return;
    const on = this.get(); yp.classList.toggle('min', on);
    if (this.btn) { this.btn.replaceChildren(ico(on ? 'i_zoomin' : 'i_zoomout', 16)); this.btn.setAttribute('aria-label', on ? I18n.s("u_63b75bdbd3ef") : I18n.s("u_fb1a2d03b3eb")); this.btn.title = on ? I18n.s("u_63b75bdbd3ef") : I18n.s("u_1031a9d3dd40"); }
    if (this.pp) this.pp.replaceChildren(ico(Music.playing ? 'i_pause' : 'i_play', 16));
    requestAnimationFrame(() => YTPlace.apply());
  },
  build() {
    const yp = document.getElementById('ytpanel'), hd = yp && yp.querySelector('.yt-h'), x = document.getElementById('yt-close'); if (!hd || this.btn) return;
    this.pp = h('button', { class: 'xbtn yt-pp', type: 'button', 'aria-label': I18n.s("u_bdb3feb8e0a3"), onclick: () => { Music.toggle(); setTimeout(() => this.apply(), 300); } });
    this.btn = h('button', { class: 'xbtn yt-min', type: 'button', onclick: () => this.set(!this.get()) });
    this.dockBtn = h('button', { class: 'xbtn yt-dock', type: 'button', 'aria-label': I18n.s("u_b2fd0792912d"), title: I18n.s("u_31c0ba1897d5"), text: I18n.s("u_aa03cd91ca77"), onclick: () => YTMiniPlace.dock() });
    hd.insertBefore(this.pp, x); hd.insertBefore(this.btn, x); hd.insertBefore(this.dockBtn, x); YTMiniPlace.build(); this.apply();
  },
};
(function () {
  window.addEventListener('load', () => YTMini.build());
  const ch = Music.changed ? Music.changed.bind(Music) : null;
  if (ch) Music.changed = function () { const r = ch.apply(this, arguments); try { YTMini.apply(); } catch (e) { } return r; };
})();

// phone: lyrics sit just under the room (in the page), never on top of it
(function () {
  const tick = Lyrics.tick.bind(Lyrics);
  Lyrics.tick = function () {
    const el = this.mount(), m = document.body.classList.contains('m'), st = document.querySelector('.stage'), wrap = document.querySelector('.room-wrap');
    if (m && st && wrap && el.parentNode !== st) st.insertBefore(el, wrap.nextSibling);
    else if (!m && el.parentNode !== document.body) document.body.append(el);
    return tick();
  };
})();

// Temporary gains never overwrite the player's saved volume setting.
const Duck = {
  k:1,quizK:1,focus:null,t:null,request:0,
  vol(k){this.k=k;Music.applyVolume()},
  start(ms){const id=++this.request;clearTimeout(this.t);this.vol(.25);this.t=setTimeout(()=>this.end(id),ms||5000);return id},
  end(id){if(id!=null&&id!==this.request)return;clearTimeout(this.t);this.t=null;this.vol(1)},
  released(id){if(id!==this.request)return;clearTimeout(this.t);this.t=setTimeout(()=>this.end(id),250)},
  syncQuiz(){
    const w=UI.wins[this.focus];let active=false;
    if(w&&!w.el.hidden){
      if(this.focus==='study')active=Learn.sess?.step==='quiz';
      if(this.focus==='catstypo'&&typeof CatsTypo!=='undefined')active=!!(CatsTypo.engaged&&CatsTypo.session&&!CatsTypo.session.done);
    }
    const k=active?.7:1;if(this.quizK!==k){this.quizK=k;Music.applyVolume()}
  }
};
(function(){
 const say=Learn.say.bind(Learn);
 Learn.say=function(w){
  if(!this.tts()||!String(w||'').trim())return say(w);
  Duck.syncQuiz();const id=Duck.start(Math.min(30000,5000+String(w).length*150));
  const result=say(w),u=this.utterance;
  if(!result){Duck.end(id);return result}
  if(u)for(const name of ['onend','onerror']){const previous=u[name];u[name]=function(...args){try{previous?.apply(this,args)}finally{Duck.released(id)}}}
  return result;
 };
 for(const name of ['openWin','closeWin','raise','render']){
  const previous=UI[name].bind(UI);
  UI[name]=function(...args){const result=previous(...args);if(name==='openWin')Duck.focus=args[0];if(name==='raise')Duck.focus=args[0].id;Duck.syncQuiz();return result};
 }
 for(const name of ['toQuiz','finish']){const previous=Learn[name].bind(Learn);Learn[name]=function(...args){const result=previous(...args);Duck.syncQuiz();return result}}
 const changed=Music.changed.bind(Music);Music.changed=function(...args){this.applyVolume();return changed(...args)};
})();
