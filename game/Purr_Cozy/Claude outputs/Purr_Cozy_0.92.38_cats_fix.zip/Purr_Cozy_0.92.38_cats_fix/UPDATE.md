# 0.92.38 貓咪美術修正（抓癢、翻肚、金色配件）

修正 0.92.35 裡改壞的地方：

1. **抓癢**：恢復你原本的抓癢姿勢（側身、頭往上），只把臉改成和其他姿勢同一套畫法：額頭亮帶、兩格高的眼睛、鼻子。不再是貼一顆大正臉上去。
2. **翻肚的配件**：項圈／鈴鐺／領巾改畫在脖子（頭和身體交界那一格），蝴蝶結／花／皇冠改畫在倒過來的頭上（右下的耳朵旁），不再是一條橫過肚子的色帶和飄在空中的蝴蝶結。
3. **皇冠、鈴鐺、花心**：原本用的是毛色調色格 `w`/`x`，換毛色時會一起被染成毛色，所以 cocoa／grey／ink／snow 身上幾乎看不到。改用同樣顏色但不會被重新上色的調色格，五種毛色都看得到金色；動作動畫的 `js/cat-action-accessories.js` 也同步改，坐著和跳起來顏色一致。

`purrcozy\` 共 12 個檔案，目錄結構和遊戲根目錄相同：

| 位置 | 檔案 |
|---|---|
| `assets\png\masks\` | `cats.png`、`shared0.png`、`shared1.png` |
| `assets\png\atlases\` | `shared0.png`、`shared1.png` |
| `assets\png\cats\` | `base`、`ginger`、`cocoa`、`grey`、`ink`、`snow` |
| `js\` | `cat-action-accessories.js` |

動作動畫的 170 張 PNG 沒有變，不在這包裡。

## 更新步驟

1. 把 `purrcozy\` 裡的 `assets` 和 `js` 複製到遊戲根目錄覆蓋（我也已經直接寫進 `D:\Dropbox\Github\html\game\Purr_Cozy`，用這包覆蓋一次可以換回小檔案的 PNG）。
2. `version.json` 版本改成 `0.92.38`。
3. 執行 `Rebuild-Resources.cmd`。
4. 遊戲裡看：抓癢的貓、翻肚戴配件的貓、戴皇冠／鈴鐺的 cocoa 或 ink 貓。
5. 一起 commit：改到的檔案、`build-manifests\`、`resources.json`、`version.json`。

`preview\cat_fix_0.92.38_preview.png` 是原本／上一版／這一版的對照。
