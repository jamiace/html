# 0.92.35 貓咪美術更新（三批合併）

這包包含三批修改：

1. **cat_fix**：一般姿勢 29 張，套到 5 種毛色和所有配件組合。
2. **cat_fix2**：動作動畫 34 張，包括跳、下來、跑、蹲、揮掌、哈氣，套到 5 種毛色。
   - 動作動畫裡的貓也會顯示配件，由新的 `js/cat-action-accessories.js` 在遊戲中畫上去。
3. **抓癢的臉**：改成和其他姿勢同一張臉。抓癢和翻肚原本不顯示配件，現在也會顯示。

`purrcozy\` 的目錄結構和遊戲根目錄相同，共 183 個檔案：

| 位置 | 檔案 |
|---|---|
| `assets\png\masks\` | `cats.png`、`shared0.png`、`shared1.png`（遊戲實際用來畫貓的調色遮罩） |
| `assets\png\atlases\` | `shared0.png`、`shared1.png`（只改了貓的格子） |
| `assets\png\cats\` | `base`、`ginger`、`cocoa`、`grey`、`ink`、`snow` 共 6 張 |
| `assets\png\actions\` | 34 個動作格 × 5 色，共 170 張 |
| `js\` | `cat-action-accessories.js`（新檔）、`bootstrap.js`（只多載入上面那個新檔，CRLF 保留） |

## 更新步驟

這些檔案我已經直接寫進 `D:\Dropbox\Github\html\game\Purr_Cozy`。

不過經由電腦連線寫入時，PNG 會被重新壓縮成比較大的檔案（畫面完全相同）。所以建議你還是用這包覆蓋一次，換回小檔案。

1. **（可略過）檢查**：
   ```
   node purrcozy\tools\check-cats.cjs "D:\Dropbox\Github\html\game\Purr_Cozy"
   ```
   因為上面說的重新壓縮，大多數圖片會顯示 DIFF。這是正常的。
2. **覆蓋**：把 `purrcozy\` 裡的 `assets` 和 `js` 兩個資料夾複製到遊戲根目錄，全部覆蓋。
   - `tools\check-cats.cjs` 只是檢查工具，不需要放進遊戲。
   - 覆蓋完再跑一次步驟 1，應該會顯示「需要更新：0 個」。
3. **改版號**：把 `version.json` 的版本改成 `0.92.35`。
4. **重建資源**：執行 `Rebuild-Resources.cmd`。新的 `js/cat-action-accessories.js` 和圖片要收進資源檔，遊戲才會載入。
5. **在遊戲裡確認**：
   - 抓癢的臉和坐姿一樣。
   - 戴配件的貓在跳、跑、哈氣時，配件會跟著。
   - 5 種毛色都看一下。
6. **提交**：把變更的檔案、`build-manifests\`、`resources.json`、`version.json` 一起 commit。

## 備註

- `preview\` 裡有三張預覽圖：所有姿勢、動作動畫、抓癢。
- 打架動作在遊戲裡顯示的是揚塵特效，不是貓本身，所以沒有加配件。
- 舊的紅、藍、緞帶、圍巾、帽子組合，商店裡沒有在賣，遊戲中看不到：紅、藍顯示成項圈，其餘不顯示配件。
- `cat_fix` 的抓癢兩張和 `cat_walk3` 有 28 個顏色不在調色盤上，已換成最接近的調色盤顏色。
