// 後台帳號與權限的安全規則測試（admins / staff / adminlog / learnlog）。npm run test:rules 會一起執行。
import {initializeTestEnvironment,assertSucceeds,assertFails} from '@firebase/rules-unit-testing';
import {readFileSync} from 'fs';
import {doc,getDoc,setDoc,updateDoc,deleteDoc,collection,getDocs,addDoc,collectionGroup,query,limit,orderBy,serverTimestamp} from 'firebase/firestore';
import test from 'node:test';
const env=await initializeTestEnvironment({projectId:'demo-admin-rules',firestore:{rules:readFileSync(new URL('../firestore.rules', import.meta.url),'utf8'),host:'127.0.0.1',port:8080}});
const as=(email,verified=true,uid=email)=>env.authenticatedContext(uid,{email,email_verified:verified}).firestore();
await env.withSecurityRulesDisabled(async c=>{const d=c.firestore();
 await setDoc(doc(d,'admins/boss@gmail.com'),{name:''});
 const st=(role,active=true)=>({role,active,name:'',note:'',createdBy:'boss@gmail.com',createdAt:new Date(),updatedBy:'boss@gmail.com',updatedAt:new Date()});
 await setDoc(doc(d,'staff/mgr@gmail.com'),st('manager'));await setDoc(doc(d,'staff/ana@gmail.com'),st('analyst'));await setDoc(doc(d,'staff/off@gmail.com'),st('analyst',false));
 await setDoc(doc(d,'learnlog/u1/lsess/s1'),{v:1});});
const staff=(by,role)=>({role,active:true,name:'x',note:'',createdBy:by,createdAt:serverTimestamp(),updatedBy:by,updatedAt:serverTimestamp()});
const cg=db=>getDocs(query(collectionGroup(db,'lsess'),limit(10)));
test('read logs',async()=>{await assertSucceeds(cg(as('boss@gmail.com')));await assertSucceeds(cg(as('mgr@gmail.com')));await assertSucceeds(cg(as('ana@gmail.com')));
 await assertFails(cg(as('off@gmail.com')));await assertFails(cg(as('nobody@gmail.com')));await assertFails(cg(as('boss@gmail.com',false)));await assertSucceeds(cg(as('BOSS@gmail.com')));});
test('who am i',async()=>{await assertSucceeds(getDoc(doc(as('boss@gmail.com'),'admins/boss@gmail.com')));await assertSucceeds(getDoc(doc(as('ana@gmail.com'),'admins/ana@gmail.com')));
 await assertFails(getDoc(doc(as('ana@gmail.com'),'admins/boss@gmail.com')));await assertSucceeds(getDoc(doc(as('ana@gmail.com'),'staff/ana@gmail.com')));await assertFails(getDoc(doc(as('ana@gmail.com'),'staff/mgr@gmail.com')));});
test('admins not writable',async()=>{await assertFails(setDoc(doc(as('boss@gmail.com'),'admins/x@gmail.com'),{name:''}));});
test('list staff',async()=>{await assertSucceeds(getDocs(collection(as('mgr@gmail.com'),'staff')));await assertFails(getDocs(collection(as('ana@gmail.com'),'staff')));await assertSucceeds(getDocs(collection(as('boss@gmail.com'),'admins')));await assertFails(getDocs(collection(as('mgr@gmail.com'),'admins')));});
test('create staff',async()=>{await assertSucceeds(setDoc(doc(as('boss@gmail.com'),'staff/new1@gmail.com'),staff('boss@gmail.com','manager')));
 await assertSucceeds(setDoc(doc(as('mgr@gmail.com'),'staff/new2@gmail.com'),staff('mgr@gmail.com','analyst')));
 await assertFails(setDoc(doc(as('mgr@gmail.com'),'staff/new3@gmail.com'),staff('mgr@gmail.com','manager')));
 await assertFails(setDoc(doc(as('ana@gmail.com'),'staff/new4@gmail.com'),staff('ana@gmail.com','analyst')));
 await assertFails(setDoc(doc(as('boss@gmail.com'),'staff/Bad@gmail.com'),staff('boss@gmail.com','analyst')));
 await assertFails(setDoc(doc(as('boss@gmail.com'),'staff/new5@gmail.com'),{...staff('boss@gmail.com','analyst'),extra:1}));
 await assertFails(setDoc(doc(as('mgr@gmail.com'),'staff/new6@gmail.com'),staff('boss@gmail.com','analyst')));});
test('update/delete staff',async()=>{const m=as('mgr@gmail.com');
 await assertSucceeds(updateDoc(doc(m,'staff/ana@gmail.com'),{active:false,updatedBy:'mgr@gmail.com',updatedAt:serverTimestamp()}));
 await assertFails(updateDoc(doc(m,'staff/ana@gmail.com'),{role:'manager',updatedBy:'mgr@gmail.com',updatedAt:serverTimestamp()}));
 await assertFails(updateDoc(doc(m,'staff/mgr@gmail.com'),{name:'me',updatedBy:'mgr@gmail.com',updatedAt:serverTimestamp()}));
 await assertFails(updateDoc(doc(m,'staff/new1@gmail.com'),{active:false,updatedBy:'mgr@gmail.com',updatedAt:serverTimestamp()}));
 await assertSucceeds(updateDoc(doc(as('boss@gmail.com'),'staff/new1@gmail.com'),{role:'analyst',updatedBy:'boss@gmail.com',updatedAt:serverTimestamp()}));
 await assertFails(updateDoc(doc(as('boss@gmail.com'),'staff/new1@gmail.com'),{createdBy:'x',updatedBy:'boss@gmail.com',updatedAt:serverTimestamp()}));
 await assertFails(deleteDoc(doc(m,'staff/mgr@gmail.com')));await assertSucceeds(deleteDoc(doc(m,'staff/new2@gmail.com')));});
test('learnlog delete',async()=>{await assertFails(deleteDoc(doc(as('ana@gmail.com'),'learnlog/u1/lsess/s1')));await assertSucceeds(deleteDoc(doc(as('mgr@gmail.com'),'learnlog/u1/lsess/s1')));});
test('audit',async()=>{const l={by:'mgr@gmail.com',role:'manager',act:'login',target:'',detail:'',at:serverTimestamp()};
 await assertSucceeds(addDoc(collection(as('mgr@gmail.com'),'adminlog'),l));await assertFails(addDoc(collection(as('mgr@gmail.com'),'adminlog'),{...l,by:'boss@gmail.com'}));await assertFails(addDoc(collection(as('ana@gmail.com'),'adminlog'),{...l,by:'ana@gmail.com'}));
 await assertFails(addDoc(collection(as('nobody@gmail.com'),'adminlog'),{...l,by:'nobody@gmail.com'}));
 await assertFails(getDocs(collection(as('ana@gmail.com'),'adminlog')));await assertSucceeds(getDocs(collection(as('mgr@gmail.com'),'adminlog')));});
test.after(()=>env.cleanup());
test('0.92.46 fields: profile/board grade, learnlog pl',async()=>{
 const p=(over={})=>({name:'a',code:'ABCDEF',status:'',ava:{},lvl:1,pets:[],wk:'w2026-11-02',wm:0,tm:0,room:'{}',dev:false,at:serverTimestamp(),...over});
 const u=env.authenticatedContext('alice').firestore();
 await assertSucceeds(setDoc(doc(u,'profiles/alice'),p({grade:'小三'})));await assertSucceeds(setDoc(doc(u,'profiles/alice'),p()));
 await assertFails(setDoc(doc(u,'profiles/alice'),p({grade:'x'.repeat(13)})));await assertFails(setDoc(doc(u,'profiles/alice'),p({grade:3})));
 const b=(over={})=>({name:'a',ava:{},lvl:1,lv:1,coins:0,tm:0,w:{},dev:false,at:serverTimestamp(),...over});
 await assertSucceeds(setDoc(doc(u,'board/alice'),b({grade:'國一'})));await assertFails(setDoc(doc(u,'board/alice'),b({grade:5})));
 const anon=env.authenticatedContext('anon1').firestore();
 const rec=(over={})=>({v:1,id:'s9',lid:'anon1',acct:'',dev:'',app:'0.92.46',lang:'zh-TW',kind:'grade',sub:'first',t0:1,t1:2,dur:1,done:true,stop:'result',n:10,right:7,coins:60,xp:40,streak:0,lv:'1',ans:[],rev:[],typo:[],at:serverTimestamp(),...over});
 await assertSucceeds(setDoc(doc(anon,'learnlog/anon1/lsess/s9'),rec({pl:{m:'first',t:3.2,se:.7,n:10,r:7,g:3,d:3,p:-1,mu:3,sd:3}})));
 await assertSucceeds(setDoc(doc(anon,'learnlog/anon1/lsess/s10'),rec({id:'s10'})));
 await assertFails(setDoc(doc(anon,'learnlog/anon1/lsess/s11'),rec({id:'s11',pl:'bad'})));
});
test('0.5.01 player accounts: saves, backups, players registry',async()=>{
 await env.withSecurityRulesDisabled(async c=>{const d=c.firestore();
  await setDoc(doc(d,'staff/ana2@gmail.com'),{role:'analyst',active:true,name:'',note:'',createdBy:'boss@gmail.com',createdAt:new Date(),updatedBy:'boss@gmail.com',updatedAt:new Date()});
  await setDoc(doc(d,'saves/kid1'),{v:1,schema:3,rev:4,savedAt:1,device:'d',lvl:2,coins:10,email:'kid1@x.com',dev:false,sync:{},data:'{"v":1}',updated:new Date()});
  await setDoc(doc(d,'saves/kid2'),{v:1,schema:3,rev:1,savedAt:1,device:'d',lvl:2,coins:10,email:'',dev:true,sync:{},data:'{"v":1}',updated:new Date()});});
 const save=(rev,over={})=>({v:1,schema:3,rev,savedAt:2,device:'admin',lvl:3,coins:500,email:'kid1@x.com',dev:false,sync:{admin:'mgr@gmail.com'},data:'{"v":1,"coins":500}',updated:serverTimestamp(),...over});
 const m=as('mgr@gmail.com'),a=as('ana2@gmail.com'),kid=env.authenticatedContext('kid1').firestore(),other=env.authenticatedContext('kid9').firestore();
 // read
 await assertSucceeds(getDoc(doc(m,'saves/kid1')));await assertSucceeds(getDocs(collection(m,'saves')));await assertSucceeds(getDoc(doc(as('boss@gmail.com'),'saves/kid1')));
 await assertFails(getDoc(doc(a,'saves/kid1')));await assertFails(getDocs(collection(a,'saves')));await assertFails(getDoc(doc(other,'saves/kid1')));await assertFails(getDocs(collection(kid,'saves')));
 // write: rev +1 and stamped with the manager's own email
 await assertFails(setDoc(doc(m,'saves/kid1'),save(4)));await assertFails(setDoc(doc(m,'saves/kid1'),save(5,{sync:{}})));await assertFails(setDoc(doc(m,'saves/kid1'),save(5,{sync:{admin:'boss@gmail.com'}})));
 await assertFails(setDoc(doc(a,'saves/kid1'),save(5,{sync:{admin:'ana2@gmail.com'}})));
 await assertSucceeds(setDoc(doc(m,'saves/kid1'),save(5)));
 await assertFails(setDoc(doc(m,'saves/kid2'),save(2,{dev:false})));await assertSucceeds(setDoc(doc(m,'saves/kid2'),save(2,{dev:true})));
 await assertFails(deleteDoc(doc(m,'saves/kid1')));
 // the player keeps writing normally afterwards
 await assertSucceeds(setDoc(doc(kid,'saves/kid1'),save(6,{sync:{}})));
 // backups
 const bk={v:1,at:1,reason:'admin',device:'admin',savedAt:1,lvl:1,coins:1,data:'{}',updated:serverTimestamp()};
 await assertSucceeds(addDoc(collection(m,'saves/kid1/backups'),bk));await assertSucceeds(getDocs(collection(m,'saves/kid1/backups')));
 await assertFails(addDoc(collection(a,'saves/kid1/backups'),bk));await assertFails(getDocs(collection(a,'saves/kid1/backups')));
 // players registry
 const pl=(by,over={})=>({email:'t01@purrcozy.test',name:'測試01',test:true,group:'claude',note:'',seed:{name:'測試01',coins:100},disabled:false,createdBy:by,createdAt:serverTimestamp(),updatedBy:by,updatedAt:serverTimestamp(),...over});
 await assertSucceeds(setDoc(doc(m,'players/t01'),pl('mgr@gmail.com')));
 await assertFails(setDoc(doc(m,'players/t02'),pl('boss@gmail.com')));
 await assertFails(setDoc(doc(a,'players/t03'),pl('ana2@gmail.com')));
 await assertFails(setDoc(doc(m,'players/t04'),{...pl('mgr@gmail.com'),password:'x'}));
 await assertSucceeds(updateDoc(doc(as('boss@gmail.com'),'players/t01'),{note:'ok',updatedBy:'boss@gmail.com',updatedAt:serverTimestamp()}));
 await assertFails(updateDoc(doc(m,'players/t01'),{createdBy:'x',updatedBy:'mgr@gmail.com',updatedAt:serverTimestamp()}));
 await assertSucceeds(getDoc(doc(env.authenticatedContext('t01').firestore(),'players/t01')));
 await assertFails(getDoc(doc(env.authenticatedContext('t05').firestore(),'players/t01')));
 await assertFails(getDocs(collection(a,'players')));await assertSucceeds(getDocs(collection(m,'players')));
 await assertSucceeds(deleteDoc(doc(m,'players/t01')));
});
test('0.92.48 daily behaviour summaries (bday)',async()=>{
 const u=env.authenticatedContext('anon7').firestore();
 const day=(over={})=>({v:1,d:'2026-11-07',lid:'anon7',acct:'',dev:'abc',app:'0.92.48',tester:false,min:12.5,sess:2,h:{'20':10,'21':2.5},win:{learn:2},wt:{learn:6.25},mini:{pinball:1},fp:{},mus:8,songs:3,pet:{ball:2},furn:{sofa:1},edit:0,focus:0,soc:{},first:'20:05',last:'21:10',at:serverTimestamp(),...over});
 await assertSucceeds(setDoc(doc(u,'learnlog/anon7/bday/2026-11-07'),day()));
 await assertSucceeds(setDoc(doc(u,'learnlog/anon7/bday/2026-11-07'),day({min:20,sess:3})));
 await assertSucceeds(setDoc(doc(u,'learnlog/anon7/bday/2026-11-07'),day({v:2,vis:35.5,wt:{learn:6,room:4,pet:2}})));await assertFails(setDoc(doc(u,'learnlog/anon7/bday/2026-11-07'),day({v:3})));await assertFails(setDoc(doc(u,'learnlog/anon7/bday/2026-11-07'),day({vis:2000})));
 await assertFails(setDoc(doc(u,'learnlog/anon7/bday/2026-11-08'),day()));
 await assertFails(setDoc(doc(u,'learnlog/anon7/bday/bad'),day({d:'bad'})));
 await assertFails(setDoc(doc(u,'learnlog/anon7/bday/2026-11-07'),day({extra:1})));
 await assertFails(setDoc(doc(u,'learnlog/anon7/bday/2026-11-07'),day({min:5000})));
 await assertFails(setDoc(doc(env.authenticatedContext('anon8').firestore(),'learnlog/anon7/bday/2026-11-07'),day()));
 const big={};for(let i=0;i<50;i++)big['w'+i]=1;await assertFails(setDoc(doc(u,'learnlog/anon7/bday/2026-11-07'),day({win:big})));
 const cgq=db=>getDocs(query(collectionGroup(db,'bday'),limit(10)));
 await assertSucceeds(cgq(as('ana2@gmail.com')));await assertFails(cgq(as('ana@gmail.com')));await assertFails(cgq(as('nobody@gmail.com')));await assertFails(cgq(u));
 await assertFails(deleteDoc(doc(as('ana2@gmail.com'),'learnlog/anon7/bday/2026-11-07')));await assertSucceeds(deleteDoc(doc(as('mgr@gmail.com'),'learnlog/anon7/bday/2026-11-07')));
});
test('0.92.49 weekly level contest (contest/{week}/rows|test/{uid})',async()=>{
 const k1=env.authenticatedContext('kid1').firestore(),k2=env.authenticatedContext('kid2').firestore();
 const row=(over={})=>({name:'小美',ava:{},grade:'G5',l:3,a:867,n:45,s:3867,tries:1,at:serverTimestamp(),...over});
 await assertSucceeds(setDoc(doc(k1,'contest/w2026-11-02/rows/kid1'),row()));
 await assertSucceeds(setDoc(doc(k1,'contest/w2026-11-02/rows/kid1'),row({l:6,a:1000,s:7000,tries:2})));
 await assertSucceeds(setDoc(doc(k1,'contest/w2026-11-02/test/kid1'),row()));
 await assertFails(setDoc(doc(k1,'contest/w2026-11-02/rows/kid1'),row({s:9999})));          // score must match
 await assertFails(setDoc(doc(k1,'contest/w2026-11-02/rows/kid1'),row({l:7,s:7867})));
 await assertFails(setDoc(doc(k1,'contest/w2026-11-02/rows/kid1'),row({a:1200,s:4200})));
 await assertFails(setDoc(doc(k1,'contest/w2026-11-02/rows/kid1'),row({extra:1})));
 await assertFails(setDoc(doc(k1,'contest/w2026-11-02/other/kid1'),row()));
 await assertFails(setDoc(doc(k1,'contest/badweek/rows/kid1'),row()));
 await assertFails(setDoc(doc(k2,'contest/w2026-11-02/rows/kid1'),row()));                 // only your own row
 await assertSucceeds(getDocs(query(collection(k2,'contest/w2026-11-02/rows'),orderBy('s','desc'),limit(50))));
 await assertFails(getDocs(query(collection(k2,'contest/w2026-11-02/rows'),orderBy('s','desc'),limit(51))));
 await assertFails(getDocs(query(collection(env.unauthenticatedContext().firestore(),'contest/w2026-11-02/rows'),limit(10))));
 await assertSucceeds(getDocs(collection(as('mgr@gmail.com'),'contest/w2026-11-02/rows')));await assertSucceeds(getDocs(collection(as('ana2@gmail.com'),'contest/w2026-11-02/test')));
 await assertFails(deleteDoc(doc(k2,'contest/w2026-11-02/rows/kid1')));await assertSucceeds(deleteDoc(doc(as('mgr@gmail.com'),'contest/w2026-11-02/rows/kid1')));
});
