/* Meow Typo: free practice and resumable daily spelling challenges. */
const CatsTypo={
 session:null, engaged:false, timers:new Set(), active:false, cursor:0, value:'', mark:-1, phase:'idle',
 later(fn,ms){const id=setTimeout(()=>{this.timers.delete(id);fn()},ms);this.timers.add(id);return id},
 clear(){for(const id of this.timers)clearTimeout(id);this.timers.clear();this.phase='idle';const host=this.host();host?.querySelector('.ct-cat')?.classList.remove('ct-ready','ct-press');host?.querySelectorAll('.ct-hit').forEach(k=>k.classList.remove('ct-hit'))},
 open(){if(this.session?.mode==='daily'){this.close();this.session=null}UI.openWin('catstypo')},
 openDaily(){Life.ensureDaily();const task=Challenge.task('c_spell');if(!task)return;if(!Challenge.tierOf(task)){UI.openTasks('daily');return}const remaining=Challenge.left(task);if(!remaining.length){UI.openTasks('daily');return}this.clear();this.session={mode:'daily',day:Life.L.daily.day,task,words:remaining.map(w=>VOCAB[VIDX[w]]),at:0,correct:0,helped:0,typos:0,attempts:0,done:false};UI.openWin('catstypo');this.nextQuestion()},
 dailyValid(){const s=this.session;return s?.mode!=='daily'||(Life.L.daily?.day===s.day&&Challenge.task('c_spell')===s.task)},
 banner(onclick){return h('button',{class:'ct-banner',type:'button',onclick:onclick||(()=>this.open()),'aria-label':I18n.s("u_c7f04f3144f5")},h('img',{src:'assets/cats-typo/kitten.png',alt:''}),h('span',{class:'ct-banner-copy'},h('strong',{text:"Meow Typo"}),h('span',{text:I18n.s("u_2407f558ce4e")}),h('small',{text:I18n.s("u_25ffdbe5623b")})),h('span',{class:'ct-banner-go','aria-hidden':'true'},I18n.s("u_a19fe0c92a78")))},
 autoAdvance(){const session=this.session,at=session?.at;if(!session?.answered||session.revealed||session.done)return;const started=performance.now(),voice=Learn.utterance;const next=()=>{const win=UI.wins.catstypo;if(document.hidden||!win||win.el.hidden||this.session!==session||session.at!==at)return;if(voice&&Learn.utterance===voice&&performance.now()-started<6000&&(speechSynthesis.speaking||speechSynthesis.pending)){this.later(next,100);return}this.advance()};this.later(next,2000)},
 answer(v,done){
  const input=h('input',{class:'ct-entry',type:'text',lang:'en',inputmode:'none',autocomplete:'off',autocapitalize:'off',autocorrect:'off',spellcheck:'false',enterkeyhint:'done',disabled:done,'aria-label':I18n.t('meow.input',[v.w.length]),value:this.value});
  input.addEventListener('input',()=>{if(done)return;if(input.value.toLowerCase()!==this.value)TypoSound.key();this.setValue(input.value.toLowerCase());this.cursor=input.selectionStart??this.value.length;this.mark=-1;this.paint()});
  const sync=()=>{this.cursor=input.selectionStart??this.value.length;this.paint()};input.addEventListener('keyup',sync);input.addEventListener('click',sync);
  const answer=h('label',{class:'ct-answer'},input,h('span',{class:'ct-slots','aria-hidden':'true','data-i18n-skip':true}));
  answer.addEventListener('pointerdown',e=>{if(done)return;const cells=[...answer.querySelectorAll('.ct-slot')];if(!cells.length)return;let best=cells[0],distance=Infinity;for(const cell of cells){const r=cell.getBoundingClientRect(),d=Math.hypot(e.clientX-(r.left+r.width/2),2*(e.clientY-(r.top+r.height/2)));if(d<distance){distance=d;best=cell}}const r=best.getBoundingClientRect();this.cursor=Math.min(this.value.length,Number(best.dataset.ctIndex)+(e.clientX>r.left+r.width/2?1:0));e.preventDefault();input.focus({preventScroll:true});this.paint(true)});return answer;
 },

 start(){this.clear();const levels=new Set(Learn.levelsOn());let pool=VOCAB.filter(v=>levels.has(v.t)&&/^[a-z]+(?:[ '-][a-z]+)*$/i.test(v.w)&&v.w.length<=22);pool=Adaptive.select(pool.map(v=>v.i),5,'spell').map(i=>VOCAB[i]);this.session={words:pool.slice(0,5),at:0,correct:0,helped:0,typos:0,attempts:0,done:false};this.nextQuestion()},
 nextQuestion(){this.clear();if(this.session)this.session.miss=0;this.value='';this.cursor=0;this.mark=-1;this.fitQuestion();this.catFlags=[];this.session.answered=false;this.session.revealed=false;this.active=true;this.engaged=true;TypoSound.unlock();UI.refresh('catstypo');Duck.syncQuiz();Learn.speak(this.current().w);this.schedule()},
 current(){return this.session?.words[this.session.at]},
 // 0.92.44: free practice no longer sticks to L1. Spelling is aimed a little harder than quizzes (~70% instead of 85%, it
 // allows retries), each round of five mixes: 3 words at the player's level, 1 word they have studied in the daily review,
 // and 1 "stretch" word from the next checked level up, and the same level is not repeated three times in a row.
 practicePick(pool,q){const s=this.session,slot=s.at%5,recent=s.words.slice(Math.max(0,s.at-2),s.at).map(v=>v.t),seen=new Set((Adaptive.state().recent||[]).slice(-20));
  const sample=pool.length>600?shuffle(pool.slice()).slice(0,600):pool;
  const best=(list,T)=>{let b=null,score=Infinity;for(const i of list){const v=VOCAB[i],p=Adaptive.probability(i,'spell',q),sc=Math.abs(p-T)+(recent.length===2&&recent[0]===v.t&&recent[1]===v.t?.2:0)+(seen.has(i)?.1:0)+Math.random()*.06;if(sc<score){score=sc;b=i}}return b};
  const fit=best(sample,.7);if(fit==null)return null;
  if(slot===1){const studied=pool.filter(i=>{const r=Learn.P[VOCAB[i].w];return r&&r[0]>=1});if(studied.length)return best(studied.length>600?shuffle(studied).slice(0,600):studied,.6)}
  if(slot===3){const lv=VOCAB[fit].t,up=Learn.levelsOn().filter(l=>l>lv)[0];if(up){const harder=sample.filter(i=>VOCAB[i].t===up);if(harder.length)return best(harder,.5)}}
  return fit},
 fitQuestion(){const s=this.session,used=new Set(s.words.slice(0,s.at).map(v=>v.i)),q={noHint:s.task?.tier==='h'};
  let pool=s.mode==='daily'?s.words.slice(s.at).map(v=>v.i):Adaptive.pool().filter(i=>!used.has(i)&&/^[a-z]+(?:[ '-][a-z]+)*$/i.test(VOCAB[i].w)&&VOCAB[i].w.length<=22);
  // 0.92.51 先教再考: practice spells words the player has already met (once there are enough of them)
  if(s.mode!=='daily'){const met=pool.filter(i=>Learn.P[VOCAB[i].w]);if(met.length>=15)pool=met}
  const [id]=s.mode==='daily'?Adaptive.select(pool,1,'spell',{mix:false,q}):[this.practicePick(pool,q)];if(id==null)return;
  if(s.mode==='daily'){const at=s.words.findIndex((v,k)=>k>=s.at&&v.i===id);[s.words[s.at],s.words[at]]=[s.words[at],s.words[s.at]]}else s.words[s.at]=VOCAB[id];
 },
 setValue(next){const old=this.value;let a=0,b=0;while(a<old.length&&a<next.length&&old[a]===next[a])a++;while(b<old.length-a&&b<next.length-a&&old[old.length-1-b]===next[next.length-1-b])b++;this.catFlags=(this.catFlags||[]).slice(0,a).concat(Array(next.length-a-b).fill(false),b?(this.catFlags||[]).slice(old.length-b):[]);this.value=next},
 assess(ok){const s=this.session;if(Adaptive.note(s,this.current().i,'spell',ok,{noHint:s.task?.tier==='h'})){Game.save();saveSoon()}},
 schedule(){if(!this.active||this.session?.answered||document.hidden)return;this.later(()=>this.warn(),3800+Math.random()*2200)},

 moveTo(letter,lift=0){const host=this.host(),key=host?.querySelector('[data-ct-key="'+letter+'"]'),cat=host?.querySelector('.ct-cat'),board=host?.querySelector('.ct-board');if(!key||!cat||!board)return;const a=key.getBoundingClientRect(),b=board.getBoundingClientRect();cat.style.left=(a.left-b.left-board.clientLeft+a.width/2-cat.offsetWidth*.585)+'px';cat.style.top=(a.top-b.top-board.clientTop+a.height/2-cat.offsetHeight*.92-lift)+'px';},
 warn(){if(!this.active||this.session?.answered||document.hidden)return;this.phase='ready';this.pendingLetter='abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random()*26)];this.notice(I18n.s("u_526be8874d24"));this.moveTo(this.pendingLetter,12);this.host()?.querySelector('.ct-cat')?.classList.add('ct-ready');this.later(()=>this.strike(this.pendingLetter),1000)},
 strike(letter){if(!this.active||this.session?.answered||document.hidden)return;letter=letter||this.pendingLetter||'x';this.phase='press';const host=this.host(),key=host?.querySelector('[data-ct-key="'+letter+'"]'),cat=host?.querySelector('.ct-cat');cat?.classList.remove('ct-ready');this.moveTo(letter,0);cat?.classList.add('ct-press');this.later(()=>{if(!this.active||this.session?.answered)return;this.session.typos++;this.insert(letter,true);TypoSound.meow();this.notice(I18n.s("u_b70cca8e6a2d")+letter.toUpperCase());key?.classList.add('ct-hit');this.later(()=>{cat?.classList.remove('ct-press');key?.classList.remove('ct-hit');this.phase='idle';this.schedule()},450)},180)},
 host(){return UI.wins.catstypo?.body},
 notice(text){const el=this.host()?.querySelector('.ct-notice');if(el)el.textContent=text},
 insert(text,cat=false){if(this.session?.answered||!this.active)return;TypoSound.key();this.catFlags.splice(this.cursor,0,...Array(text.length).fill(cat));this.value=this.value.slice(0,this.cursor)+text+this.value.slice(this.cursor);this.mark=cat?this.cursor:-1;this.cursor+=text.length;this.paint(true)},
 key(key){if(!this.active||this.session?.answered)return;if(key==='Backspace'||key==='Delete')TypoSound.key();if(key==='Enter'){this.submit();return}if(key==='ArrowLeft')this.cursor=Math.max(0,this.cursor-1);else if(key==='ArrowRight')this.cursor=Math.min(this.value.length,this.cursor+1);else if(key==='Home')this.cursor=0;else if(key==='End')this.cursor=this.value.length;else if(key==='Backspace'){if(this.cursor){this.catFlags.splice(this.cursor-1,1);this.value=this.value.slice(0,this.cursor-1)+this.value.slice(this.cursor);this.cursor--}this.mark=-1}else if(key==='Delete'){this.catFlags.splice(this.cursor,1);this.value=this.value.slice(0,this.cursor)+this.value.slice(this.cursor+1);this.mark=-1}else if(/^[a-zA-Z '-]$/.test(key)){this.insert(key.toLowerCase());return}this.paint(true)},
 paint(forceSelection=false){const answer=this.host()?.querySelector('.ct-answer'),el=answer?.querySelector('.ct-slots'),input=answer?.querySelector('.ct-entry'),v=this.current();if(!el||!input||!v)return;
  if(input.value!==this.value||forceSelection){input.value=this.value;try{input.setSelectionRange(this.cursor,this.cursor)}catch{}}
  el.replaceChildren();const letters=(v.w.match(/[a-z]/ig)||[]).length,normal=this.session?.task?.tier!=='h',last=v.w.search(/[a-z](?!.*[a-z])/i);
  const length=Math.max(v.w.length,this.value.length);for(let i=0;i<length;i++){
   const target=v.w[i]||'',hint=normal&&/[a-z]/i.test(target)&&(i===0||(letters>=7&&i===last)),typed=this.value[i]||'';
   const cell=h('span',{class:'ct-slot'+(!typed&&hint?' ct-hint':'')+(i===this.mark?' ct-letter-hit':'')+(i===this.cursor&&!this.session?.answered?' ct-current':'')+(i>=v.w.length?' ct-extra':'')+(i===length-1&&this.cursor===length&&!this.session?.answered?' ct-at-end':''),'data-ct-index':i,text:typed||(hint?target:' ')});el.append(cell);
  }
 },
 submit(){const s=this.session;if(!this.active||s.answered)return;TypoSound.enter();s.attempts++;if(!Learn.isAnswer(this.current(),this.value)){if(!this.catFlags.some(Boolean))this.assess(false);/* 0.92.49: three tries, then the answer is shown and the round moves on */s.miss=(s.miss||0)+1;if(s.miss>=3){this.reveal();return}this.notice(I18n.t('meow.tryLeft',[3-s.miss]));return}Life.ensureDaily();if(!this.dailyValid()){this.close();this.session=null;UI.openTasks('daily');return}this.assess(true);this.clear();s.answered=true;s.correct++;this.active=false;Learn.speak(this.current().w);
 if(s.mode==='daily'){const v=this.current();Learn.grade(v.i,true);Challenge.got(s.task,v.w);Life.track('quizRight',1);Life.track('engRight',1);Game.save();saveSoon();}UI.refresh('catstypo');this.autoAdvance()},
 reveal(){if(!this.active)return;this.assess(false);const s=this.session,v=this.current();if(s.mode==='daily'&&v&&!(s.graded||(s.graded=new Set())).has(v.i)){s.graded.add(v.i);Learn.grade(v.i,false);Game.save()}this.clear();this.session.answered=true;this.session.revealed=true;this.session.helped++;this.active=false;UI.refresh('catstypo')},
 advance(){this.clear();const S0=this.session;if(S0.mode==='daily'&&S0.revealed){/* 0.92.49: a missed word comes back once at most, then the round ends whatever the result (it used to come back until it was spelled right) */const v=this.current(),rq=S0.requeued||(S0.requeued={});if(!rq[v.i]){rq[v.i]=1;S0.words.push(v)}}if(++this.session.at>=this.session.words.length){this.clear();this.active=false;this.session.done=true;UI.refresh('catstypo')}else this.nextQuestion()},
 close(){this.active=false;this.engaged=false;this.clear();document.body.classList.remove('ct-open');Duck.syncQuiz()},
 render(){const s=this.session, pet=Game.S.zoo?.pets?.find(p=>p.home)||Game.S.zoo?.pets?.[0];const title=h('div',{class:'ct-top'},h('div',{},h('small',{text:"MEOW TYPO"}),h('h3',{text:I18n.s("u_2407f558ce4e")})),h('span',{class:'ct-counter',text:s&&!s.done?(s.at+1)+' / '+s.words.length:s?.mode==='daily'?I18n.t('meow.dailyTitle'):I18n.s("u_420991acae06")}));
 if(!s||s.done){const daily=s?.mode==='daily';return[h('div',{class:'ct-shell ct-intro'},
  title,h('img',{class:'ct-intro-cat',src:'assets/cats-typo/kitten.png',alt:I18n.s('u_2abe1e99fc97')}),
  h('section',{class:'ct-info-card'},h('h2',{text:s?I18n.s('u_4cadd4a2d562'):I18n.s('u_df8178b606d3')}),
   h('p',{class:'ct-description',text:s?I18n.t('meow.summary',[s.correct,s.helped,s.typos]):I18n.s('u_cba1d6cc496b')}),
   h('p',{class:'ct-help',text:I18n.t(daily?'meow.dailyHelp':'meow.practiceHelp')})),
  h('button',{class:'ct-btn ct-primary',onclick:()=>daily?UI.openTasks('daily'):this.start()},daily?I18n.t('meow.backTasks'):s?I18n.s('u_f34087eaae1a'):I18n.s('u_cfc6d34deace')))];}

 const v=this.current(),done=s.answered;const question=h('div',{class:'ct-question'},title,h('div',{class:'ct-prompt'},h('span',{'data-i18n-skip':true,text:v.z}),h('button',{class:'ct-sound',type:'button','aria-label':I18n.s("u_8ad01d76080c"),onclick:()=>Learn.speak(v.w)},'♫')),h('div',{class:'ct-meta',text:v.p+' · Level '+v.t}),this.answer(v,done),h('small',{class:'ct-letter-count',text:I18n.t('spell.letterCount',[(v.w.match(/[a-z]/ig)||[]).length])}),h('div',{class:'ct-notice',role:'status','aria-live':'polite',text:done?(s.revealed?I18n.s("u_1c85749cba53")+v.w+I18n.s("u_2b8a54924425"):I18n.s("u_68f2b8e07036")+v.w+I18n.s("u_6f2b4364a93b")+(s.at===s.words.length-1?I18n.s("u_f6a53aff23c2"):I18n.s("u_8e600464f7b0"))):I18n.s("u_4d053f3fd918")}));
 const board=h('div',{class:'ct-board'},h('img',{class:'ct-cat',src:'assets/cats-typo/kitten.png',alt:I18n.s("u_7b3bc2a67b36")}),h('div',{class:'ct-board-label'},h('strong',{text:I18n.s("u_2bb41aa6bdbb")}),h('small',{text:I18n.s("u_75d84e84cda6")})),h('span',{class:'ct-paw',hidden:true,'aria-hidden':'true'},'🐾'));
 board.addEventListener('pointerdown',e=>{if(e.target.closest('button')){e.preventDefault();this.host()?.querySelector('.ct-entry')?.focus({preventScroll:true})}});
 for(const row of ['qwertyuiop','asdfghjkl','zxcvbnm'])board.append(h('div',{class:'ct-keyrow'},...Array.from(row,k=>h('button',{type:'button',class:'ct-key','data-ct-key':k,disabled:done,onclick:()=>this.key(k)},k.toUpperCase()))));
 board.append(h('div',{class:'ct-keyrow ct-actions'},...[["'","'"],['-','－'],[' ',I18n.s("u_f0bf4574ce25")],['Backspace',I18n.s("u_4dff2515ccf8")],['Enter','↵ Enter']].map(([k,label])=>h('button',{type:'button',class:'ct-key '+(k==='Enter'?'ct-enter':''),'data-ct-key':k,disabled:done,onclick:()=>this.key(k)},label))));
 const foot=h('div',{class:'ct-foot'},h('button',{class:'ct-btn',onclick:()=>{this.cursor=Math.max(0,this.cursor-1);this.paint(true)},disabled:done,'aria-label':I18n.s("u_d6e6693fa41a")},'←'),h('button',{class:'ct-btn',onclick:()=>{this.cursor=Math.min(this.value.length,this.cursor+1);this.paint(true)},disabled:done,'aria-label':I18n.s("u_094a7e587d32")},'→'),h('button',{class:'ct-btn',onclick:()=>{this.value='';this.cursor=0;this.paint(true)},disabled:done},I18n.s("u_1ef3de06b32e")),done?h('button',{class:'ct-btn ct-primary',onclick:()=>this.advance()},s.at===s.words.length-1?I18n.s("u_1878a0380c7f"):I18n.s("u_a17f5ad55696")):h('button',{class:'ct-btn',onclick:()=>this.reveal()},I18n.s("u_1b4bce9df73d")));
 requestAnimationFrame(()=>{this.paint(true);if(this.active)this.host()?.querySelector('.ct-entry')?.focus({preventScroll:true})});return[h('div',{class:'ct-shell'},question,board,foot)];}
};
(function(){UI.WIN.catstypo={t:'Meow Typo',i:'i_paw',w:820,at:['c',0]};UI.w_catstypo=()=>CatsTypo.render();const learn=UI.w_learn.bind(UI);UI.w_learn=function(){return[CatsTypo.banner(),...learn()]};UI.WIN.typodesk={t:I18n.s("u_b1996c73b3a3"),i:'i_book',w:360,at:['c',0]};UI.w_typodesk=()=>[h('p',{class:'hint',text:I18n.s("u_a9faeabfd8fe")}),h('button',{class:'chip',onclick:()=>{UI.closeWin('typodesk');UI.openWin('timer')}},I18n.s("u_6b9853a8a528")),CatsTypo.banner(()=>{UI.closeWin('typodesk');CatsTypo.open()})];const desk=Game.interact.bind(Game);Game.interact=function(it){if(ITEMS[it.k]?.desk&&!Room.edit&&!Life.needOf('item',it.uid)){UI.openWin('typodesk');return}return desk(it)};const timer=UI.w_timer.bind(UI);UI.w_timer=function(){return[...timer(),CatsTypo.banner()]};const open=UI.openWin.bind(UI);UI.openWin=function(id){if(id!=='catstypo')CatsTypo.close();const r=open(id);if(id==='catstypo'){CatsTypo.clear();CatsTypo.engaged=!!(CatsTypo.session&&!CatsTypo.session.done);document.body.classList.add('ct-open');if(CatsTypo.session&&!CatsTypo.session.answered&&!CatsTypo.session.done){CatsTypo.active=true;CatsTypo.schedule()}else CatsTypo.autoAdvance();Duck.syncQuiz()}return r};const close=UI.closeWin.bind(UI);UI.closeWin=function(id){if(id==='catstypo'){CatsTypo.close();document.body.classList.remove('ct-open')}return close(id)};document.addEventListener('keydown',e=>{const w=UI.wins.catstypo;if(!w||w.el.hidden||!CatsTypo.active||e.isComposing||e.ctrlKey||e.metaKey||e.altKey)return;if(e.key==='Enter'&&e.target.tagName==='BUTTON'&&!e.target.closest('.ct-board'))return;if(e.target.classList.contains('ct-entry')&&e.key!=='Enter')return;if(/^[a-zA-Z '-]$/.test(e.key)||['Enter','Backspace','Delete','ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();e.stopImmediatePropagation();CatsTypo.key(e.key)}},true);document.addEventListener('visibilitychange',()=>{CatsTypo.clear();if(!document.hidden){if(CatsTypo.active)CatsTypo.schedule();else CatsTypo.autoAdvance()}});})();

// Bring a paused desktop session back when its window is focused again.
(function(){
 const raise=UI.raise.bind(UI);
 UI.raise=function(w){
  const result=raise(w);
  if(w.id==='catstypo'){
   document.body.classList.add('ct-open');
   if(CatsTypo.session&&!CatsTypo.session.done&&!CatsTypo.engaged){
    CatsTypo.engaged=true;
    if(!CatsTypo.session.answered){CatsTypo.active=true;CatsTypo.schedule()}else CatsTypo.autoAdvance();
   }
  }else if(CatsTypo.engaged||document.body.classList.contains('ct-open'))CatsTypo.close();
  Duck.syncQuiz();return result;
 };
})();
